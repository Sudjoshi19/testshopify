

{% docs ecom_inventory %}

On receiving the order the Uniware does inventory allocation for the ordered item(s). If the inventory is available the item is marked Fulfillable, else Unfulfillable.

{% enddocs %}