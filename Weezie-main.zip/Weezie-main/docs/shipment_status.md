{% docs shipment_status %}

A shipment is a package containing a single or multiple items of an order. It is important to note that the items in an order can be fulfilled in multiple shipments, even by same seller. Also, a shipment cannot have items from different orders.'

{% enddocs %}