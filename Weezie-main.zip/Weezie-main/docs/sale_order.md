{% docs sales_order %}
The sale order management at large comprises of getting orders from various online sales channels, followed by picking the order item(s) from the storage area, do the quality check, pack the Q.C. passed item(s) and finally handing over the shipment(s) to the logistics provider for delivery to customer.

{% enddocs %}